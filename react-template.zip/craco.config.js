const CracoLessPlugin = require('craco-less');
// const { getThemeVariables } = require('antd/dist/theme');
// import AntdDayjsWebpackPlugin from 'antd-dayjs-webpack-plugin';
const AntdDayjsWebpackPlugin = require('antd-dayjs-webpack-plugin');
const SimpleProgressWebpackPlugin = require( 'simple-progress-webpack-plugin' );
const path = require("path")
const { name } = require('./package');
module.exports = {



  devServer: _ => {
    const config = _;
    config.headers = {
      'Access-Control-Allow-Origin': '*',
    };
    config.historyApiFallback = true;
    config.hot = false;
    config.watchContentBase = false;
    config.liveReload = false;
    return config;
  },


  webpack:{
    plugins: [
      new AntdDayjsWebpackPlugin(),
      new SimpleProgressWebpackPlugin()
    ],
    configure: (webpackConfig, { env, paths}) => {
      // paths.appPath='public'
      paths.appBuild = 'dist'
      webpackConfig.output = {
        ...webpackConfig.output,
          path: path.resolve(__dirname, 'dist'), // 修改输出文件目录
          publicPath: './',


          library:`${name}-[name]`,
          libraryTarget : 'umd',
          jsonpFunction : `webpackJsonp_${name}`,
          globalObject: 'window'
      }
      return webpackConfig
    },

  },
  plugins: [
    
    {
      plugin: CracoLessPlugin, 
      options: {
        lessLoaderOptions: {
          lessOptions: {
            modifyVars: { '@primary-color': '#1DA57A' },
            javascriptEnabled: true,
          },
        },
      },
    }
  ]
};
// module.exports = {
//   plugins: [
//     new AntdDayjsWebpackPlugin()
//   ]
// };