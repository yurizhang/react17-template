import {useEffect, useState} from 'react';
import axios from 'axios'
function App() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState([]);
  
    // Note: the empty deps array [] means
    // this useEffect will run once
    // similar to componentDidMount()
    useEffect(() => {
    //   fetch("./mock/1.json").then(res => res.json()).then((result) => {
    //         setIsLoaded(true);
    //         console.log({result})
    //         setItems(result.data);
    //       },
    //       // Note: it's important to handle errors here
    //       // instead of a catch() block so that we don't swallow
    //       // exceptions from actual bugs in components.

    //       (error) => {
    //         setIsLoaded(true);
    //         setError(error);
    //       }
    //     );
          async function fetchData() {
            // You can await here
            const res=await axios.get("./mock/1.json").catch( (error)=> {
                     setIsLoaded(false);
                     setError(error);
            });
            console.log({res});
            if(res){
                setIsLoaded(true);
                setItems(res.data.data);
            }

            
          }
          fetchData()
          

        
    }, []);
  
    if (error) {
      return <div>Error: {error.response && error.response.status}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <ul>
            <li>hello</li>
          {items.map(item => (
            <li key={item.id}>
              {item.name} {item.price}
            </li>
          ))}
        </ul>
      );
    }
  }
  export default App;