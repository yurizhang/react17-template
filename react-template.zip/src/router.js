import React from 'react';
import NoMatch from './404';
const IndexApp = React.lazy(() => import('./view/index/index'));
const AboutApp = React.lazy(() => import('./view/about/index'));
// import IndexApp from './view/index/index';
// import AboutApp from './view/about/index';

let routes = [

    {
        path: '/about',
        key:1,
        components: AboutApp,
        exact: true
    },
    {
        path: '/about/:topicId',
        key:2,
        components: AboutApp,
        exact: true
    },    
    {
        path: '/index',
        components: IndexApp,
        key:3,
        exact: true
    }, 
    {
        path: '/',
        components: IndexApp,
        key:4,
        exact: true
    },     
    {
        path: '*',
        components: NoMatch,
        key:404,
        exact: false
    },         
]

export default routes;