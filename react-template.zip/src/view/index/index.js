import logo from '../../assets/img/logo.svg';
import {Link} from 'react-router-dom';
import { DatePicker, Space } from 'antd';
function App() {
  const onChange=(date, dateString)=> {
    console.log(date, dateString);
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
         this is index
        </p>
        <Link to="/about">关于</Link>
      </header>
      <Space direction="vertical">
        <DatePicker onChange={onChange} />
        <DatePicker onChange={onChange} picker="week" />
        <DatePicker onChange={onChange} picker="month" />
        <DatePicker onChange={onChange} picker="quarter" />
        <DatePicker onChange={onChange} picker="year" />
      </Space>
    </div>
  );
}

export default App;
