
import {Link,useHistory, useParams} from 'react-router-dom';
import DemoAjax from '../../component/demo.js';
import { Button } from 'antd';
function App() {
  const history = useHistory();
  let { topicId } = useParams();
  const goHome = (props) => {
    console.log(props);
    history.push({
        pathname: '/index',
        search:"?a=2345",
        state: {
            identityId: 1
        }
    })
  }
  return (
    <div className="App">
      <header className="App-header">
        <p>
          {topicId}:this is about pages, and <Button  type="primary" onClick={goHome}>跳到首页</Button>
        </p>
        <Link to="/">首页</Link>

        <div>

           <DemoAjax />
        </div>

      </header>
    </div>
  );
}

export default App;
