import './public-path';
import React,{Suspense} from 'react';
import ReactDOM from 'react-dom';
import { HashRouter as Router, Redirect, Route, Switch, Link} from 'react-router-dom';
// import 'antd/dist/antd.css';


import './assets/css/antd.less';
import './assets/css/common.css';
import './assets/css/index.css';
// import IndexApp from './view/index/index';
// import AboutApp from './view/about/index';
// import NoMatch from './404';
import routes from './router'
import reportWebVitals from './reportWebVitals';
// import 'dayjs/locale/zh-cn'
// dayjs.locale('zh-cn')

const App=()=>{
    return(
    <React.StrictMode>
    <Router>
      <header>
          <Link to="/">首页</Link> | 
          <Link to="/about">关于</Link>
      </header>
      <Suspense fallback={<div>Loading....</div>}>
          <Switch>
                {
                      routes.map((item,key)=> {
                            if (item.exact) {
                                return <Route key={key} exact path={item.path} component={item.components}/>
                            } else {
                                return <Route key={key} path={item.path} component={item.components}/>
                            }
                        })
                }
                <Redirect  to="/index" from="/default" exact />
              

          </Switch>
      </Suspense>
    </Router>
  </React.StrictMode>
  );
}


// ReactDOM.render(
//   <App />,
//   document.getElementById('root')
// );




function render(props) {
  const { container } = props;
  ReactDOM.render(<App />, container ? container.querySelector('#root') : document.querySelector('#root'));
}
if (!window.__POWERED_BY_QIANKUN__) {
  render({});
}
export async function bootstrap() {
  console.log('[react16] react app bootstraped');
}
export async function mount(props) {
  console.log('[react16] props from main framework', props);
  render(props);
}

// 增加 update 钩子以便主应用手动更新微应用
export async function update(props) {
  render(props);
}
export async function unmount(props) {
  const { container } = props;
  ReactDOM.unmountComponentAtNode(container ? container.querySelector('#root') : document.querySelector('#root'));
}



// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals


// <Route path='/about' exact render={(props) => {
//    return <About {...props} name={'cedric'} />
//}}>

// </Route>
reportWebVitals(console.log);
